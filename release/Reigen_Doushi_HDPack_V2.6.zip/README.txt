靈幻道士 中文化 V2.6（繁中／简中）Mesen HD Pack
================================================

內容
- 全遊戲中文文字（對話、門口說明、標題選單、取名／密碼畫面按鈕、玩家名字）換成 4 倍解析度。
- 原版遊戲的字塊也換成高解析版：假名（取名／密碼畫面）、標點、
  標題畫面英文字、游標與提示記號。
- 最上方的狀態欄（村名、古法書數量、物品）維持原版圖案。
- 字型：思源宋體（Source Han Serif，本包使用與其同字形的 Noto Serif CJK SemiBold）。
  繁中用繁體字形、简中用簡體字形、假名用日文字形。

安裝（Mesen 2）
1. 把整個資料夾放到 Mesen 的 HdPacks 資料夾內。
2. 資料夾名稱必須和 ROM 檔名（不含 .nes）相同。
   例：ROM 是 Reigen_Doushi_CHT_CHS_V2.6.nes → HdPacks\Reigen_Doushi_CHT_CHS_V2.6\hires.txt
3. Mesen 設定 → 影像 → 勾選「使用 HD Pack」，重新載入遊戲。

適用：Reigen_Doushi_(CHT_CHS)_V2.6（有無頭像版都可以；以畫面圖塊內容比對，不看檔案雜湊）。
之後版本只要文字、字型沒變也能用；改了翻譯需要重新產生。

授權：思源宋體／Noto Serif CJK 以 SIL Open Font License 1.1 授權，© Adobe / Google。
本包圖片由該字型繪製而成。
